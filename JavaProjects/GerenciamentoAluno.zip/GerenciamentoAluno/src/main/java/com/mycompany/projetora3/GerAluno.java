/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projetora3;

import java.io.*;
import java.util.ArrayList;
import java.util.List;


public class GerAluno {
    private List<Aluno> alunos;
    private String arquivo;

    public GerAluno(String arquivo) {
        this.arquivo = arquivo;
        alunos = new ArrayList<>();
    }

    public void adicionarAluno(Aluno aluno) {
        alunos.add(aluno);
    }

    public void removerAluno(Aluno aluno) {
        alunos.remove(aluno);
    }

    public List<Aluno> getAlunos() {
        return alunos;
    }

    public void salvarAlunos() throws IOException {
        ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(arquivo));
        for (Aluno aluno : alunos) {
            outputStream.writeObject(aluno);
        }
        outputStream.close();
    }

    public void recuperarAlunos() throws IOException, ClassNotFoundException {
        ObjectInputStream inputStream = null;
        try {
            inputStream = new ObjectInputStream(new FileInputStream(arquivo));
            while (true) {
                Aluno aluno = (Aluno) inputStream.readObject();
                alunos.add(aluno);
            }
        } catch (EOFException e) {
            // Fim do arquivo
        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
        }
    }
}

