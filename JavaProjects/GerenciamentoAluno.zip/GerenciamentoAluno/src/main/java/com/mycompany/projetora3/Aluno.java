package com.mycompany.projetora3;
import java.io.Serializable;

public class Aluno extends Estudante implements Serializable{
    private String nome;
    private String matricula;
    private int semestre;

    public Aluno(String nome, String matricula, int semestre) {
        this.nome = nome;
        this.matricula = matricula;
        this.semestre = semestre;
    }

    @Override
    public String getNome() {
        return nome;
    }

    @Override
    public void setNome(String titulo) {
        this.nome = nome;
    }

    @Override
    public String getMatricula() {
        return matricula;
    }

    @Override
    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    @Override
    public int getSemestre() {
        return semestre;
    }

    @Override
    public void setSemestre(int semestre) {
        this.semestre = semestre;
    }

    @Override
    public String toString() {
        return "Aluno{" +
                "nome='" + nome + '\'' +
                ", matricula='" + matricula + '\'' +
                ", semestre=" + semestre +
                '}';
    }
}
