/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projetora3;

/**
 *
 * @author TiLtas
 */
public abstract class Estudante {
    public abstract String getNome();
    public abstract void setNome(String nome);
    public abstract String getMatricula();
    public abstract void setMatricula(String matricula);
    public abstract int getSemestre();
    public abstract void setSemestre(int semestre);
}
