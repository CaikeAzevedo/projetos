package com.mycompany.projetora3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.awt.event.*;

public class Projetora3 {
    private static GerAluno gerAluno;
    private static JFrame frame;
    private static JTextArea outputTextArea;

    private static final String LOG_FILE = "log.txt";

    public static void main(String[] args) {
        gerAluno = new GerAluno("alunos.ser");

        frame = new JFrame("Sistema de Gerenciamento de Alunos");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1500, 600);

        ImageIcon background = new ImageIcon("GerenciamentoAluno/Assets/image.png");

        JPanel mainPanel = new JPanel(new BorderLayout());

        outputTextArea = new JTextArea();
        outputTextArea.setEditable(false);

        JScrollPane scrollPane = new JScrollPane(outputTextArea);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new GridLayout(4, 2));

        JButton adicionarAlunoButton = createStyledButton("Adicionar Aluno");
        adicionarAlunoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Aluno alunoAdicionado = adicionarAluno();
                registrarAcao("Aluno adicionado: " + alunoAdicionado.toString());
            }
        });
        buttonPanel.add(adicionarAlunoButton);

        JButton removerAlunoButton = createStyledButton("Remover Aluno");
        removerAlunoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Aluno alunoRemovido = removerAluno();
                registrarAcao("Aluno removido: " + alunoRemovido.toString());
            }
        });
        buttonPanel.add(removerAlunoButton);

        JButton salvarAlunosButton = createStyledButton("Salvar Alunos");
        salvarAlunosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                salvarAlunos();
            }
        });
        buttonPanel.add(salvarAlunosButton);

        JButton recuperarAlunosButton = createStyledButton("Recuperar Alunos");
        recuperarAlunosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                recuperarAlunos();
            }
        });
        buttonPanel.add(recuperarAlunosButton);

        JButton pesquisarAlunoButton = createStyledButton("Pesquisar Aluno");
        pesquisarAlunoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                pesquisarAluno();
            }
        });
        buttonPanel.add(pesquisarAlunoButton);

        JButton lerAlunosButton = createStyledButton("Alunos antigos (ainda salvos)");
        lerAlunosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                lerAlunos();
            }
        });
        buttonPanel.add(lerAlunosButton);

        JButton listarTodosAlunosButton = createStyledButton("Listar Todos os Alunos");
        listarTodosAlunosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                listarTodosAlunos();
            }
        });
        buttonPanel.add(listarTodosAlunosButton);

        JButton logRegistrosButton = createStyledButton("Log de registros");
        logRegistrosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exibirLogRegistros();
            }
        });
        buttonPanel.add(logRegistrosButton);

        mainPanel.add(buttonPanel, BorderLayout.EAST);

        frame.getContentPane().add(mainPanel);
        frame.setVisible(true);
    }

    private static JButton createStyledButton(String text) {
    JButton button = new JButton(text);
    button.setFocusPainted(false);
    button.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    button.setBackground(new Color(189, 236, 182)); // Altera a cor de fundo para verde claro
    button.setForeground(Color.BLACK);

    Color originalBackground = button.getBackground();

    button.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseEntered(MouseEvent e) {
            button.setBackground(new Color(144, 238, 144)); // Altera a cor de fundo para verde mais escuro ao passar o mouse
        }

        @Override
        public void mouseExited(MouseEvent e) {
            button.setBackground(originalBackground); // Retorna à cor de fundo original ao sair do mouse
        }
    });

    return button;
}


private static Aluno adicionarAluno() {
    String nome = JOptionPane.showInputDialog(frame, "Digite o nome do Aluno:");
    String matricula = JOptionPane.showInputDialog(frame, "Digite a matricula do Aluno:");
    int semestre = Integer.parseInt(JOptionPane.showInputDialog(frame, "Digite o semestre do Aluno:"));
    
    Aluno aluno = new Aluno(nome, matricula, semestre);
    gerAluno.adicionarAluno(aluno);
    
    outputTextArea.append("Aluno adicionado: " + aluno.toString() + "\n");
    
    return aluno;
}

private static Aluno removerAluno() {
    String nome = JOptionPane.showInputDialog(frame, "Digite o nome do aluno a ser removido:");
    
    Aluno alunoRemover = null;
    for (Aluno l : gerAluno.getAlunos()) {
        if (l.getNome().equals(nome)) {
            alunoRemover = l;
            break;
        }
    }
    
    if (alunoRemover != null) {
        gerAluno.removerAluno(alunoRemover);
        outputTextArea.append("Aluno removido: " + alunoRemover.toString() + "\n");
    } else {
        outputTextArea.append("Aluno não encontrado.\n");
    }
    
    return alunoRemover;
}

private static void listarAlunos() {
    outputTextArea.setText("");
    for (Aluno aluno : gerAluno.getAlunos()) {
        outputTextArea.append(aluno.toString() + "\n");
    }
}

private static void salvarAlunos() {
    try {
        gerAluno.salvarAlunos();
        outputTextArea.append("Alunos salvos com sucesso.\n");
    } catch (IOException e) {
        outputTextArea.append("Erro ao salvar os alunos: " + e.getMessage() + "\n");
    }
}

private static void recuperarAlunos() {
    try {
        gerAluno.recuperarAlunos();
        outputTextArea.append("Alunos recuperados com sucesso.\n");
    } catch (IOException | ClassNotFoundException e) {
        outputTextArea.append("Erro ao recuperar os alunos: " + e.getMessage() + "\n");
    }
}

private static void pesquisarAluno() {
    String nome = JOptionPane.showInputDialog(frame, "Digite o nome do aluno a ser pesquisado:");
    
    Aluno alunoEncontrado = null;
    for (Aluno l : gerAluno.getAlunos()) {
        if (l.getNome().equals(nome)) {
            alunoEncontrado = l;
            break;
        }
    }
    
    if (alunoEncontrado != null) {
        outputTextArea.append("Aluno encontrado: " + alunoEncontrado.toString() + "\n");
    } else {
        outputTextArea.append("Aluno não encontrado.\n");
    }
}

private static void listarTodosAlunos() {
    outputTextArea.setText("");
    for (Aluno aluno : gerAluno.getAlunos()) {
        outputTextArea.append(aluno.toString() + "\n");
    }
}

private static void registrarAcao(String acao) {
    try {
        BufferedWriter writer = new BufferedWriter(new FileWriter(LOG_FILE, true));
        writer.write(acao);
        writer.newLine();
        writer.close();
    } catch (IOException e) {
        e.printStackTrace();
    }
}

private static void exibirLogRegistros() {
    try {
        BufferedReader reader = new BufferedReader(new FileReader(LOG_FILE));
        String line;
        outputTextArea.setText("");
        while ((line = reader.readLine()) != null) {
            outputTextArea.append(line + "\n");
        }
        reader.close();
    } catch (IOException e) {
        e.printStackTrace();
    }
}

private static void lerAlunos() {
    try {
        BufferedReader reader = new BufferedReader(new FileReader("alunos.csv"));
        String line;
        outputTextArea.setText("");
        while ((line = reader.readLine()) != null) {
            outputTextArea.append(line + "\n");
        }
        reader.close();
    } catch (IOException e) {
        outputTextArea.setText("Erro ao ler os alunos: " + e.getMessage());
    }
}

}
