/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projetora3;

/**
 *
 * @author TiLtas
 */
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class CriarArquivoCSV {
    public static void main(String[] args) {
        String nomeArquivoCSV = "alunos.csv";
        String nomeArquivoTXT = "alunos.txt";

        try (PrintWriter csvWriter = new PrintWriter(new FileWriter(nomeArquivoCSV));
             PrintWriter txtWriter = new PrintWriter(new FileWriter(nomeArquivoTXT))) {

            // Escrever o cabeçalho do arquivo CSV
            csvWriter.println("nomedoaluno,nummatricula,numsemestre");

            // Gerar 100 linhas de dados de alunos aleatórios
            for (int i = 1; i <= 100; i++) {
                String nomedoaluno = "aluno_" + i;
                String nummatricula = "matricula = " + (int) (Math.random() * 101);
                String numsemestre = "semestre = " + (int) (Math.random() * 13); 

                // Escrever os dados do aluno no arquivo CSV
                csvWriter.println(nomedoaluno + "," + nummatricula + "," + numsemestre);

                // Escrever os dados do aluno no arquivo TXT
                String livroTxt = String.format("aluno: %s, matricula: %s, semestre: %s",
                        nomedoaluno, nummatricula, numsemestre);
                txtWriter.println(livroTxt);
            }

            System.out.println("Arquivos CSV e TXT criados com sucesso!");
        } catch (IOException e) {
            System.out.println("Erro ao criar os arquivos CSV e TXT: " + e.getMessage());
        }
    }
}


